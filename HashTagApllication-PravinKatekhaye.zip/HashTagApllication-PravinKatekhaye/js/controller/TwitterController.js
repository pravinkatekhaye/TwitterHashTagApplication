//TwitterController.js
(function(){


    //inject the twitterService into the controller
    angular.module('twitterApp')
        .controller('TwitterController',[ function($scope,$q, twitterService,$location) {

            $scope.tweets=[];
            $scope.relatedtweets=[];      //array of related tweets
            $scope.userprofilepic=[];     //array of user profile pic url
            $scope.userscreen_name=[];    //array of user screen name
            $scope.favoriteHashTag=[];    //array of favorite hashtag
            $scope.retweetcount=[];       //array of retweet count
            $scope.likedtweetcount=[];    //array of like tweets
            $scope.tweetsId=[];           //array of tweetsId
            $scope.citiesList=[];         //arr of citiesList



            twitterService.initialize();

            //using the OAuth authorization result get the latest 20 tweets from twitter for the user

            $scope.refreshTimeline = function(woeid) {
                twitterService.getLatestTrends(woeid).then(function(data) {
                    for(i=0;i<15;i++){
                        $scope.tweets[i] =data[0].trends[i].name;
                    }
                },function(){
                    $scope.rateLimitError = true;
                });
                $location.path("/toptrend");

            }
            //get tweet details
            $scope.getTweetsDetail=function() {
                $scope.getHashTagDetail($scope.searchForTweet);
            }

            //sign out clears the OAuth cache, the user will have to reauthenticate when returning
            $scope.signOut = function() {
                twitterService.clearCache();
                $scope.tweets.length = 0;
                $scope.$apply(function(){$scope.connectedTwitter=false})

                $scope.rateLimitError = false;
            }

            //if the user is a returning user, hide the sign in button and display the tweets
            if (twitterService.isReady()) {
                $scope.connectedTwitter = true;
                //  $scope.refreshTimeline();
            }
            //
            $scope.getHashTagDetail=function(hashtag) {
                $scope.relatedtweets.splice(0, $scope.relatedtweets.length);
                $scope.userprofilepic.splice(0,$scope.userprofilepic.length);
                $scope.userscreen_name.splice(0,$scope.userscreen_name);
                $scope.retweetcount.splice(0,$scope.retweetcount);
                $scope.likedtweetcount.splice(0,$scope.likedtweetcount);
                $scope.tweetsId.splice(0, $scope.tweetsId);


                $scope.selectedahashtag=hashtag;

                twitterService.getRelatedTweetsOfHashtag(hashtag).then(function(data) {
                    for(var i=0;i<data.statuses.length;i++){

                        $scope.relatedtweets[i]=data.statuses[i].text;
                        $scope.userprofilepic[i]=data.statuses[i].user.profile_image_url;
                        $scope.userscreen_name[i]=data.statuses[i].user.screen_name;
                        $scope.retweetcount[i]=data.statuses[i].retweet_count;
                        $scope.likedtweetcount[i]=data.statuses[i].favorite_count;
                        $scope.tweetsId[i]=data.statuses[i].id;
                    }

                });
            }

            //when the user clicks the connect twitter button, the popup authorization window opens
            $scope.connectToTwitter = function() {
                twitterService.connectTwitter().then(function() {
                    if (twitterService.isReady()) {
                        //if the authorization is successful, hide the connect button and display the tweets
                        $scope.connectedTwitter = true;
                    }

                });
            }
            //////////////////////////////////////////

            $scope.setFavoriteHashTagList=function(hashtag){
                $scope.favoriteHashTag.push(hashtag);
                alert($scope.favoriteHashTag);
            }

            $scope.favoritehashtag=function(){
                $location.path("/favoriteHashTag");
            }

            $scope.requestForLike=function(id){
                twitterService.requestForLikeTweet(id).then(function(data) {
                    alert(data);
                    console.log(""+data);
                });
            }
            $scope.homePageTimeline=function(){


                twitterService.getHomeTimelineTweets().then(function(data) {
                    $scope.relatedtweets.splice(0, $scope.relatedtweets.length);
                    $scope.userprofilepic.splice(0,$scope.userprofilepic.length);
                    $scope.userscreen_name.splice(0,$scope.userscreen_name);
                    $scope.retweetcount.splice(0,$scope.retweetcount);
                    $scope.likedtweetcount.splice(0,$scope.likedtweetcount);
                    $scope.tweetsId.splice(0, $scope.tweetsId);

                    console.log(data);
                    $scope.selectedahashtag="My TimeLine Tweets";
                    for(var i=0;i<data.length;i++){
                        $scope.relatedtweets[i]=data[i].text;
                        $scope.userprofilepic[i]=data[i].user.profile_image_url;
                        $scope.userscreen_name[i]=data[i].user.screen_name;
                        $scope.retweetcount[i]=data[i].retweet_count;
                        $scope.likedtweetcount[i]=data[i].favorite_count;
                        $scope.tweetsId[i]=data[i].id_str;
                    }

                    $location.path('/');

                });
            }


            $ ( document ).ready(function() {
                twitterService.initialize();
                $scope.homePageTimeline();
                $scope.getCityName();

            });



           $scope.changePlace=function(){
                $("#myModal").modal('show');
            }

            $scope.changeTrendLocation=function(location){

                if(location){
                    twitterService.getwoeidOfPlace(location).then(function(data) {
                        console.log(data);
                        alert(location);
                      for(var i=300;i<400;i++){
                            if(data[i].name.trim()==location.trim())
                            {
                                alert("match");
                                $scope.refreshTimeline(data[i].woeid);
                                alert(data[i].woeid);
                                break;
                            }
                        }


                    });
                }else{
                    alert("please enter the location");
                }
            };



            $scope.getCityName=function() {
                twitterService.getwoeidOfPlace(location).then(function(data) {
                    for(var i=300;i<400;i++) {
                      $scope.citiesList[i]=data[i].name.trim();
                    }
                    alert($scope.citiesList);
                });
            }




            $scope.complete = function(){
                 var myEl = angular.element(document.querySelector( '#txt_location' ));

                    $("#txt_location").autocomplete({
                        source: $scope.citiesList
                    });
            }
        }]);

})();

