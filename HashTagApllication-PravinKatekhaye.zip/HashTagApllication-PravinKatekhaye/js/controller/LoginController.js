//LoginController.js


// This getter makes code more readable and this controller looks after the redirection back to my home page of the app after login from the twitter authorize page



(function () {

    angular.module('twitterApp')
        .controller('LoginController',['$scope','twitterService', function ( $scope , twitterService ) {
            twitterService.initialize();

            //when the user clicks the connect twitter button, the popup authorization window opens populate for

            $scope.connectToTwitter = function () {

                twitterService.connectTwitter().then(function (data) {
                    if (twitterService.isReady()) {

                        $scope.connectedTwitter = true;
                    }
                });
            }

        }]);
})();